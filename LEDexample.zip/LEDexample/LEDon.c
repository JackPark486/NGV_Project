/*
 * LEDon.c
 *
 *  Created on: 2022. 3. 11.
 *      Author: user
 */

#include "TC275_Rename.h"

/* Initialize LED (RED & BLUE) */
void init_LED(void)
{
    /* Reset PC1 & PC2 in IOCR0*/
    PORT10_IOCR0 &= ~((0x1F) << PC1);
    PORT10_IOCR0 &= ~((0x1F) << PC2);

    /* Set PC1 & PC2 with push-pull(2b10000) */
    PORT10_IOCR0 |= ((0x10) << PC1);
    PORT10_IOCR0 |= ((0x10) << PC2);
}

//            PCL      PS
// not change  0       0
// set(on)     0       1
// reset(off)  1       0
// toggle      1       1

void LED1_toggle(void)
{
    PORT10_OMR |= ((1<<PCL1) | (1<<PS1));
}

void LED1_set(void)
{
    PORT10_OMR &= ~(1<<PCL1);   //set 0
    PORT10_OMR |= (1<<PS1);     //set 1
}

void LED1_clear(void)
{
    PORT10_OMR |= (1<<PCL1);    //set 1
    PORT10_OMR &= ~(1<<PS1);    //set 0
}

void LED2_toggle(void)
{
    PORT10_OMR |= ((1<<PCL2) | (1<<PS2));
}
